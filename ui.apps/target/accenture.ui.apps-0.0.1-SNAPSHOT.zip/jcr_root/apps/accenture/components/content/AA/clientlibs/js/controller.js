angular.module('', []).controller('', function($scope) {
$scope.names = [
{name:'Jani',country:'Norway'}
 ];
});